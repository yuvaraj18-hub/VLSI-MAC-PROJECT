
# Pipelined MAC Unit (VLSI Project)

This project implements a **pipelined Multiply-Accumulate (MAC) unit** using Verilog HDL. 
It was designed and simulated using **EDA Playground** and **EPWave (GTKWave)**.

## 💻 Tools Used
- Verilog / SystemVerilog
- Icarus Verilog
- EPWave (GTKWave Viewer)
- EDA Playground (online simulator)

## ✅ Features
- 3-stage pipelined MAC architecture
- Testbench with realistic inputs
- Verified with waveform simulation

## 🔗 Simulation Link
[👉 Run on EDA Playground](https://edaplayground.com/x/Di2E) <!-- Replace with your own link -->

## 📁 Files
- `pipelined_mac.v` – RTL Verilog
- `tb_pipelined_mac.v` – Testbench
